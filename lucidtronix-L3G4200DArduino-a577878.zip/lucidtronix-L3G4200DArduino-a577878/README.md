L3G4200DArduino
===============

Arduino Library for the L3G4200D Gyroscope
